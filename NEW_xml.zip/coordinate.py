from lxml.etree import Element,SubElement,tostring
import xml.etree.ElementTree as et
from osgeo import gdal
import numpy as np
import math
import os

def make_coordinate(filename):
    doc = et.parse(filename)   #解析树
    nmsp = '{http://www.opengis.net/kml/2.2}' #xpath
    b = {}
    for pm in doc.iterfind('.//{0}Placemark'.format(nmsp)):
        a = pm.find('{0}name'.format(nmsp)).text   #读取placemark名称
        for ls in pm.iterfind(
                '{0}MultiGeometry/{0}Polygon/{0}outerBoundaryIs/{0}LinearRing/{0}coordinates'.format(nmsp)):  #读取标记坐标
            b[a] = (ls.text.strip().replace(' ', '')) #将标记名称和坐标写入字典
    PointList=[]
    Rectangular_box_name=[]
    for i, j in b.items():
        m = j.split(',')
        Rectangular_box_name.append(i)
        lis = [k.strip('0') for k in m]  # 删除KML坐标中开头出现的0
        lis = [float(e) for e in lis if e != '']  # 删除空值
        del lis[-2:]

        for n in range(0,len(lis),2):
            coord_1=lis[n:n+2]
            PointList.append(coord_1)

    return PointList,Rectangular_box_name


#PointList,Rec=make_coordinate('C:/Users/Asus/Desktop/2/test1.kml')

